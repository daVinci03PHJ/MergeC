				MergeC

AUTHOR
 Hyeonjun Park
 - Affiliation: Undergraduate of Dep. Radio & Information Communication Engineering, Chungnam National Univ.
 - Contact: RICE202301996@o.cnu.ac.kr

README
 - This program employs to merge all source files('.c') in a directory as one text file('.txt').
 - This program is for students of a lecture "Computer Programming"(Prof. Kongjoo Lee of RICE, CNU)

USE
1. Put the exe file to your directory where the '.c' files are, you want to merge.
2. Execute the program, and follow the questions.

NOTICE
- This program will read files in order of names. It is recommanded that you name the files with the problem numbers(or in order by you want).
- This program will divide codes only by double newlines. It is recommanded that you put comments about problem numbers at the top of each code.

INSTALL
https://github.com/daVinci03PHJ/MergeC/blob/main/MergeCSetup.zip

NEWS
2023-09-10	Ver 1.0.0 Released

LISENCE
Copyright (C) <2023> <Hyeonjun Park(202301996, RICE, CNU)>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>